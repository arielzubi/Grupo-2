package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import view.Pantalla;

public class Marcacontrolador implements ActionListener, MouseListener, KeyListener {
    private Marca marca;
    private MarcaDao marcaDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public Marcacontrolador(Marca marca, MarcaDao marcadao, Pantalla panta) {
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btnagregar.addActionListener(this);
        //Botón de modificar autor
        this.panta.btnmodificar.addActionListener(this);
        //Botón de borrar autor
        this.panta.btnborrarM.addActionListener(this);
        //Botón de limpiar
        this.panta.btnlimpiar.addActionListener(this);
        
        //Listado de autor
        this.panta.tablamarca.addMouseListener(this);
              
        listarMarcas(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btnagregar){
            //verifica si el campo nombre está vacío
            if(panta.txt_id_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo marca es obligatorio");
            }else{
                //Realiza el agregado
                marca.setIdMarca(Integer.parseInt(panta.txt_id_marca.getText()));
                if(marcaDao.agregarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se agregó el marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el marca");
                }
            }
        }else if(e.getSource() == panta.btnmodificar){
            //verifica si el campo id está vacío
            if(panta.txt_id_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                marca.setIdMarca(Integer.parseInt(panta.txt_id_marca.getText()));
                if(marcaDao.modificarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se modificó el marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el marca");
                }
            }
        }else if(e.getSource() == panta.btnborrarM){
            //verifica si el campo id está vacío
            if(panta.txt_id_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_id_marca.getText());
                if(marcaDao.borrarMarca(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se eliminó el marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el marca");
                }
            }
        }else if(e.getSource() == panta.btnlimpiar){
                limpiarTabla();
                limpiarCampos();
                listarMarcas();    
                panta.btnagregar.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tablamarca){
            int row = panta.tablamarca.rowAtPoint(e.getPoint());
            panta.txt_id_marca.setText(panta.tablamarca.getValueAt(row,0).toString());
            panta.txtnombreMA.setText(panta.tablamarca.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btnagregar.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarMarcas(){
  panta.cmb_modelo_version.removeAllItems();
        panta.cmb_modelo_auto.removeAllItems();
      panta.cmb_marca_auto.removeAllItems();
        List<Marca> list = marcaDao.listarMarca();
        model = (DefaultTableModel) panta.tablamarca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdMarca();
            model.addRow(row);
            
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_id_marca.setText("");
    }
    
}